package com.suman.Chat_App_Backend.Service;

import org.springframework.stereotype.Service;

@Service
public class ChatService {
}
