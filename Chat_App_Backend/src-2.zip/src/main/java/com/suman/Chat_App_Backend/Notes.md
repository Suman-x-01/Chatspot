The Project Structure:
